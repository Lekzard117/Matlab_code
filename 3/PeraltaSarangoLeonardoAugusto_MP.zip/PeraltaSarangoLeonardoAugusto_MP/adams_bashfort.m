function [x, Y] = adams_bashfort(f, x0, y0, h, N)
    % Método de Adams-Bashforth de 3 pasos
    % Entrada:
    % f  - Función diferencial (f(t, y))
    % x0 - Vector con los valores iniciales x (de tamaño 3)
    % y0 - Vector con los valores iniciales y (de tamaño 3)
    % h  - Tamaño de paso
    % N  - Número total de pasos (desde x0 hasta el final)
    % 
    % Salida:
    % x  - Vector con los valores de x
    % Y  - Solución aproximada en cada punto de x

    % Inicialización
    x = linspace(x0(1), x0(1) + N*h, N+1)'; % Valores de x
    Y = zeros(N+1, 1);                      % Vector de soluciones
    Y(1:3) = y0;                            % Asignar valores iniciales

    % Implementación de Adams-Bashforth de 3 pasos
    for i = 3:N
        f_n   = f(x(i), Y(i));
        f_n1  = f(x(i-1), Y(i-1));
        f_n2  = f(x(i-2), Y(i-2));
        Y(i+1) = Y(i) + (h / 12) * (23*f_n - 16*f_n1 + 5*f_n2);
    end
end